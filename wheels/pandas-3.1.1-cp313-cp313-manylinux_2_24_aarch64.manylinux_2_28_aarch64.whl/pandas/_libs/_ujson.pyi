from collections.abc import Callable
from typing import (
    Any,
)

def ujson_dumps(
    obj: Any,
    ensure_ascii: bool = ...,
    double_precision: int = ...,
    indent: int = ...,
    orient: str = ...,
    date_unit: str = ...,
    iso_dates: bool = ...,
    default_handler: (
        Callable[[Any], str | float | bool | list[Any] | dict[Any, Any] | None] | None
    ) = ...,
) -> str: ...
def ujson_loads(
    s: str,
    precise_float: bool = ...,
    numpy: bool = ...,
    dtype: None = ...,
    labelled: bool = ...,
) -> Any: ...
